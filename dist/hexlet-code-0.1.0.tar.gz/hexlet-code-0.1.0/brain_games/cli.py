import prompt

def welcome_user():
    name = ('May I have you name?')
    print('Hello, John!')
